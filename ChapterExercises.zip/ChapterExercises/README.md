This contains the source of the exercises associated with some of the chapters of the book
Using Concurrency and Parallelism Effectively by Jon Kerridge
published by bookboon.com

Each exercise contains some lines that have been commented out and these need to be
replaced by the required coding as indicated by the comment.